package utilities;

public interface DatabaseConfig {

	public final String PersistenceUnit = "Colour-Project";
	
}
