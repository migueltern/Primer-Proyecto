drop database if exists `Getting-Started`;
create database `Getting-Started`;
