drop database if exists `Colour-Project`;
create database `Colour-Project`;
