drop database if exists `Simple-Project`;
create database `Simple-Project`;
